<p>
	<label><?php
		echo $properties['display_name'] . ':'; ?></label>
	<?php
	require $formFieldTemplateFile;
	?>
</p>
