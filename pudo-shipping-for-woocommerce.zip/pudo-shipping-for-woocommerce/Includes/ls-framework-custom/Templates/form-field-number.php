<input type="text" id="<?php
echo $identifier; ?>" name="
	<?php
		echo $identifier;
	?>
	" value="
	<?php
		echo htmlentities( $value );
	?>
	"
		class="widefat num"
		<?php
		echo $readonly;
		?>
		/>
