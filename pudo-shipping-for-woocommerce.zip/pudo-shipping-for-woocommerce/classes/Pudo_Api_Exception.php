<?php

namespace Pudo\WooCommerce;

/**
 *  Copyright: © 2025 The Courier Guy
 */
class Pudo_Api_Exception extends \Exception {



}
